# upax/__init__.py

import binascii, os, time
import rnglib, u
import upax.ftlog

__version__      = '0.3.2'
__version_date__ = '2012-06-02'


class Server(object):

#   __slots__ = ['_uDir']
    
    def __init__(self, uDir):
        """
        We expect uDir to contain two subdirectories, in/ and tmp/, and
        at least two files, L and nodeID.  L is the serialization of a 
        BoundLog.  nodeID contains a 40-byte sequence of hex digits 
        followed by a newline.  This should be unique.  

        A non-empty uDir is a DIR256x256 structure, and so it also contains
        subdirectories whose names are two hex digits and each such 
        subdirectory will contain subdirectories whose names are two hex
        digits.  Data is stored in these subdirectories; at this time
        data files are named by their SHA1 content keys and so file names
        consist of 40 hex digits.  The first two hex digits of the contena
        key select the uDir subdirectory holding the data file and the 
        second two hex digits select the subsubdirectory.

        All files in uDir should be owned by upax.upax and are (at least
        at this time) world-readable but only owner-writeable.
        """
        if not uDir:
            raise ValueError('uDir must be specified')
        self._uDir  = uDir

        _inDirPath   = os.path.join(uDir,'in')
        _logFilePath = os.path.join(uDir, 'L')
        _idFilePath  = os.path.join(uDir, 'nodeID')
        _tmpDirPath  = os.path.join(uDir, 'tmp')

        if not os.path.exists(uDir):
            os.makedirs(uDir)
        if not os.path.exists(_inDirPath):
            os.mkdir(_inDirPath)
        if not os.path.exists(_tmpDirPath):
            os.mkdir(_tmpDirPath)
        if not os.path.exists(_idFilePath):
            byteID  = bytearray(20)
            rng     = rnglib.SimpleRNG(time.time())
            rng.nextBytes(byteID)       # a low-quality quasi-random number
            id      = binascii.b2a_hex(byteID)
            self._nodeID = id
            with open(_idFilePath, 'w') as f:
                f.write (id + '\n')
        else:
            # XXX many possible problems here!
            with open( _idFilePath, 'r') as f:
                self._nodeID = f.read()[:-1]

        if not os.path.exists(_logFilePath):
            self._log = ftlog.BoundLog(ftlog.Reader([]), uDir)
        else:
            self._log = ftlog.BoundLog(ftlog.FileReader(uDir), uDir)

    def put(self, pathToFile, key, source):
        """ 
        returns (len, hash) 
        """
   
        actualKey = u.fileSHA1(pathToFile)
        if actualKey != key:
            raise ValueError('actual hash %s, claimed hash %s' % (
                actualKey, key))

        if u.exists(self._uDir, key):   return (-1, key)

        # XXX uses tempfile package, so not secure XXX
        (len, hash) = u.copyAndPut(pathToFile, self._uDir, key)

        # XXX should deal with exceptions
        self._log.addEntry( time.time(), key, self._nodeID, source, pathToFile)
        return (len, hash)

    def putData(self, data, key, source):
        """ returns (len, hash) """
        (len, hash) = u.putData(data, self._uDir, key)
        # XXX should deal with exceptions
       
        # we have no path to file
        self._log.addEntry( time.time(), key, self._nodeID, source, 
                                                            '__posted_data__')
        return (len, hash)

    def close(self):
        self._log.close() 

    # XXXthis is a reference to the actual log and so a major security risk 
    @property
    def log(self):      return self._log

    @property
    def nodeID(self):   return self._nodeID
    @property
    def uDir(self):     return self._uDir
    

class BlockingServer(Server):

    def __init__(self, uDir):
        Server.__init__(self, uDir)


class NonBlockingServer(Server):

    def __init__(self, uDir):
        pass
