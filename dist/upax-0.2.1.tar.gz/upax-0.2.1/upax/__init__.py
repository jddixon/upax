# ftlog/__init__.py

VERSION      = '0.2.1'
VERSION_DATE = '2012-02-24'
