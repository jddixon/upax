# upax/ftlog.py

import os, re, sys
from collections            import Container, Sized
from XLattice.Core.NodeID   import *

# -------------------------------------------------------------------
# CLASS LOG AND SUBCLASSES
# -------------------------------------------------------------------
class Log(Container, Sized):
    """a fault-tolerant log"""

    # XXX these should all be private
#   __slots__ = ['entries', 'index', 'timestamp', 'prevHash', 'prevMaster']

    def __init__(self, reader):
        (timestamp, prevLogHash, prevMaster, entries, index) = reader.read()
        self.timestamp  = timestamp     # seconds from epoch
        self.prevHash   = prevLogHash   # SHA1 hash of previous log
        NodeID.checkHash(self.prevHash)
        self.prevMaster = prevMaster    # nodeID of master writing prev log
        NodeID.checkHash(self.prevMaster)
        
        self.entries    = entries       # a linked list
        self.index      = index         # a map, hash => entry

    def __contains__(self, key):
        return key in self.index

    def __len__(self):
        return len(self.entries)

    def __str__(self):
        """used for serialization, so includes newline"""

        # first line 
        ret = "%10u %40s %40s\n" % (self.timestamp, 
                                    self.prevHash, self.prevMaster)
        # linked list of entries
        for entry in self.entries:
            ret += str(entry)           # woefully inefficient :-)
        return ret

    def addEntry(self, t, key, nodeID, src, path):
        entry = LogEntry(t, key, nodeID, src, path)
        self.entries.append(entry)
        self.index[key] = entry         # XXX permits duplicates!!
        return self                     # allows chaining

    def getEntry(self, key):
        if not key in self.index:
            return None
        else:
            return self.index[key]
    # GEEP
# -------------------------------------------------------------------
class BoundLog(Log):

    # XXX arguments should be self, reader, uDir, logFile
    # def __init__(self, timestamp, prevLogHash, who, uDir, logFile):
    def __init__(self, reader, uDir=None, baseName='L'):
        Log. __init__(self, reader)
        self.fd     = -1
        self.isOpen = False     # for appending
        overwriting = False
        if uDir:
            self.uDir     = uDir
            self.baseName = baseName
            overwriting   = True
        else:
            if isinstance(reader, FileReader):
                self.uDir     = reader.uDir
                self.baseName = reader.baseName
                overwriting   = False
            else:
                msg = "no target uDir/baseName specified"
                raise RuntimeError(msg)
        self.pathToLog = "%s/%s" % (self.uDir, self.baseName)
        if overwriting:
            with open(self.pathToLog, 'w') as f:
                logContents = super(BoundLog, self).__str__() 
                f.write(logContents) 
                f.close()
        self.fd     = open(self.pathToLog, 'a')
        self.isOpen = True

    def addEntry(self, t, key, nodeID, src, path):
        if not self.isOpen:
            msg = "log file %s is not open for appending" % self.pathToLog
            raise RuntimeError(msg)
        
        # XXX NEED TO THINK ABOUT THE ORDER OF OPERATIONS HERE
        super(BoundLog, self).addEntry(t, key, nodeID, src, path)
        stringified = str(self.index[key])
        self.fd.write(stringified)

    def flush(self):
        self.fd.flush()

    def close(self):
        self.fd.close()
        self.isOpen = False


# -------------------------------------------------------------------
class LogEntry():

    __slots__ = ['timestamp', 'key', 'nodeID', 'src', 'path']

    def __init__(self, timestamp, key, nodeID, source, pathToDoc):
        self.timestamp = timestamp      # seconds from epoch
        # XXX CHECK TYPE
        self.key     = key              # 40 hex digits, content hash
        NodeID.checkHash(self.key)
        self.nodeID  = nodeID           # 40 hex digits, node providing entry
        NodeID.checkHash(self.nodeID)
        self.src     = source           # tool or person responsible
        self.path    = pathToDoc        # file name

    # used in serialization, so newlines are intended
    def __str__(self):
        return '%10u %40s %40s "%s" %s\n' % (self.timestamp, self.key,
                                             self.nodeID, self.src, self.path)
    
    def equals(self, other):
        if isinstance(other, LogEntry)            and \
                self.timestamp == other.timestamp and \
                self.key       == other.key       and \
                self.nodeID    == other.nodeID    and \
                self.src       == other.src       and \
                self.path      == other.path :
            return True
        else: return False

# -------------------------------------------------------------------
# CLASS READER AND SUBCLASSES 
# -------------------------------------------------------------------
# Would prefer to be able to handle this through something like a Java
# Reader, so that we could test with a StringReader but then use a 
# FileReader in production.  If it is a file, file.readlines(sizeHint)
# supposedly has very good preformance for larger sizeHint, say 100KB
# It appears that lines returned need to be rstripped, which wastefully
# requires copying
#
# For our purposes, string input can just be split on newlines, which
# has the benefit of effectively chomping at the same time

class Reader():
    __slots__ = ['entries', 'index', 'lines']

    def __init__(self, lines):
        # XXX verify that argument is an array of strings
        self.lines = lines    
        
        ndxLast = len(self.lines) - 1
        # strip newline from last line if present
        if ndxLast >= 1:
            self.lines[ndxLast] = self.lines[ndxLast].rstrip('\n')

        # Entries are linked together as a list.  We also need a dictionary
        # that accesses each log entry using its hash.
        self.entries = []            # the empty list
        self.index   = dict()        # mapping hash => entry

    def read(self):
        
        # The first line contains timestamp, hash, nodeID for previous log.
        # Succeeding lines look like
        #  timestamp hash nodeID src path
        # In both cases timestamp is an unsigned int, the number of 
        # milliseconds since the epoch.  It can be printed with %13u.  
        # The current value (April 2011) is about 1.3 trillion (1301961973000). 

        firstLine = self.lines[0]
        if firstLine:
            FIRST_LINE_PAT = '^(\d{13}) ([0-9a-f]{40}) ([0-9a-f]{40})$'
            pat1 = re.compile(FIRST_LINE_PAT, re.I)
            m = re.match(pat1, firstLine)
            if not m:
                print "no match on first line; giving up"
                sys.exit(1)
            timestamp   = int(m.group(1))
            prevLogHash = m.group(2)
            prevMaster  = m.group(3)  
            del self.lines[0]        # so we can cleanly iterate 
        else:           
            # no first line
            timestamp   = 0
            prevLogHash = '0000000000000000000000000000000000000000'
            prevMaster  = '0000000000000000000000000000000000000000'

        entries = []
        index   = dict()
        # XXX the path expression is quite permissive 
        PATH_PAT      = '([_0-9a-z\.\-\/]+)'
        BODY_LINE_PAT = \
            '^(\d+) ([0-9a-f]{40}) ([0-9a-f]{40}) "([^"]*)" %s$' % PATH_PAT
        IGNORABLE_PAT = '(^ *$)|^ *#'
        bodyLinePat  = re.compile(BODY_LINE_PAT, re.I)
        ignorablePat = re.compile(IGNORABLE_PAT)
        for line in self.lines:
            # Read each successive line, creating an entry for each and 
            # indexing each.  Ignore blank lines and those beginning with 
            # a hash ('#')
            m = re.match(ignorablePat, line)
            if m:
                continue
            m = re.match(bodyLinePat, line)
            if m:
                t      = int(m.group(1))
                key    = m.group(2)
                nodeID = m.group(3)
                src    = m.group(4)
                path   = m.group(5)
                # constructor should catch invalid fields
                entry = LogEntry(t, key, nodeID, src, path)
                entries.append(entry)
                index[key] = entry
            else:
                msg = "not a valid log entry line: '%s'" % line
                raise RuntimeError(msg)

        return (timestamp, prevLogHash, prevMaster, entries, index)

# -------------------------------------------------------------------
class FileReader(Reader):
    """ 
    Accept uDir and optionally log file name, read entire file into
    atring array, pass to Reader.
    """
    def __init__(self, uDir, baseName = "L"):
        if not os.path.exists(uDir):
            raise RuntimeError("no such directory %s" % uDir)
        self.uDir      = uDir
        self.baseName  = baseName
        self.pathToLog = "%s/%s" % (self.uDir, baseName)
        with open(self.pathToLog, 'r') as f:
            contents = f.read()
        lines = contents.split('\n')
        Reader.__init__(self, lines) 
    # GEEP

# -------------------------------------------------------------------
class StringReader(Reader):
    """ 
    Accept a (big) string, convert to a string array, pass to Reader 
    """
    def __init__(self, bigString):
        
        # split on newlines
        lines   = bigString.split('\n')

        Reader.__init__(self, lines) 

