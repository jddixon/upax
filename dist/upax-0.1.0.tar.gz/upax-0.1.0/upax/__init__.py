# upax/upax/__init__.py

VERSION         = '0.1.0'
VERSION_DATE    = '2012-02-24'
