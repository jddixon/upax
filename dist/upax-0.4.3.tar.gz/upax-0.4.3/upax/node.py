# ~/dev/py/upax/upax/node.py

# Classes in this module should inherit from XLattice classes, but 
# currently the XLattice classes retain less desirable characteristics
# of the Java implementation such as the use of text strings to store
# byte arrays.  So get it right here and then backport to XLattice


def checkNodeID(b):
    if b is None:           raise ValueError('nodeID may not be None')
    bLen = len(b) 
    if not (bLen == 20 or bLen == 32):
        raise ValueError('invalid nodeID length %u' % bLen)

class Peer(object):
    def ___init__(self, nodeID, rsaPubkey):
        checkNodeID(nodeID) 
        self.__nodeID       = nodeID    # fBytes20 or fBytes32
        # validate ?
        self.__rsaPubkey    = rsaPubkey
        self._nodeNdx       = None      # will be uInt32

        self._cnx           = []        # list of open connections
        self._ipAddr        = []        # list of ipV4 addresses (uInt32)
        self._fqdn          = []        # list of fully qualified domain names

    @property
    def nodeID(self):       return self._nodeID
    @property
    def rsaPubkey(self):    return self._rsaPubkey
    @property
    def nodeNdx(self):      return self._nodeNdx
    @nodeNdx.setter
    def nodeNdx(self, value):
        if self._nodeNdx is not None:
            raise ValueError('nodeID may only be set once')
        if not isinstance(value, int):
            raise ValueError('nodeID must be an integer')
        if value < 0:
            raise ValueError('nodeID cannot be a negative number')
        self.nodeNdx = value

class UpaxNode(Peer):
    def ___init__(self, nodeID=None, rsaPrivkey=None):

        if rsaPrivkey == None:
            # XXX STUB XXX generate one
            pass
        self._rsaPrivkey = rsaPrivkey
        # XXX STUB: extract the private key from the public key
        super(UpaxNode, self).__init__(nodeID, rsaPubkey)

        peers           = {}    # nodeNdx (uInt32)    to Peer object
        lHashes         = {}    # nodeNdx + timestamp to LHash object
        lMap            = {}    # L hash + timestamp  to text (bytearray)

       

class LHash(object)
    def __init__(self, nodeNdx, t, hash):
        self._nodeNdx   = nodeNdx
        self._timestamp = t
        # we assume the caller guarantees that the hash is correct and
        # refers to something stored somewhere
        self._hash      = hash
